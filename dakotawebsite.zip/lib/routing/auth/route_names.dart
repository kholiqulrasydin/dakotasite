const String LoginRoute = 'login';
const String AdminHomeRoute = 'admin';
const String ReportsRoute = 'reports';
const String LogoutRoute = 'logout';