import 'package:flutter/material.dart';

const Color primaryColor = Color.fromRGBO(48, 79, 254, 1);
